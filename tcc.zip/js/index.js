
// OBSOLETO
// setResponsive = function(){
//     var topnav = document.getElementById("topnav");
//     //var btnMenu = document.getElementById("btnMenu");
    
//     if (topnav.className === "topnav"){
//         topnav.className += " responsive";
//         //btnMenu.className += " active";
//     } else {
//         topnav.className = "topnav";
//         //btnMenu.className = "icon";
//     }
// }

