function menuAnimate(x) {
  x.classList.toggle("change");
}